package client.model;

public class GameEvent
{
}
