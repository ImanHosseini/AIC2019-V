package client.model;

public enum Phase {
    PICK, MOVE, ACTION
}
